export class Student {
    id: number;
    company: string;
    name: string;
    gender: string;
    dob:string;
    phone: string;
    qualification: string;
    email: string;
    addr: string;
}
