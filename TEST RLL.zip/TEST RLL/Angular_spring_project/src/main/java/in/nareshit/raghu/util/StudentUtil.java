package in.nareshit.raghu.util;

import org.springframework.stereotype.Component;

import in.nareshit.raghu.model.Student;

@Component
public class StudentUtil {

	public void mapToActualObject(Student actual, Student student) {
		if(student.getName()!=null)
			actual.setCompany(student.getCompany());
			actual.setName(student.getName());
			actual.setGender(student.getGender());
			actual.setDob(student.getDob());
		actual.setPhone(student.getPhone());
		actual.setQualification(student.getQualification());
		if(student.getEmail()!=null)
			actual.setEmail(student.getEmail());
		actual.setAddr(student.getAddr());
	}

}
