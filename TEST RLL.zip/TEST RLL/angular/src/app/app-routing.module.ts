import { StudentEditComponent } from './student-edit/student-edit.component';
import { StudentCreateComponent } from './student-create/student-create.component';
import { StudentAllComponent } from './student-all/student-all.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomepageComponent } from './homepage/homepage.component';
import { AboutusComponent } from './aboutus/aboutus.component';
const routes: Routes = [
  {path: 'home', component: HomepageComponent},
  {path: 'all', component: StudentAllComponent},
  {path: 'add', component: StudentCreateComponent},
  {path: 'edit/:id', component: StudentEditComponent},
  {path: 'about', component: AboutusComponent},
  {path: '', redirectTo: 'home', pathMatch: 'full'},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
